import numpy as np
import torch # torch >= 1.7.1
import torch.nn.functional as F
from torchvision import transforms as T
from tqdm import tqdm


def mIoU(pred_mask, mask, smooth=1e-10, n_classes=22):
    with torch.no_grad():
        pred_mask = F.softmax(pred_mask, dim=1)
        pred_mask = torch.argmax(pred_mask, dim=1)
        pred_mask = pred_mask.contiguous().view(-1)
        mask = mask.contiguous().view(-1)

        iou_per_class = []
        dice_per_class = []
        for clas in range(0, n_classes):  # loop per pixel class
            true_class = pred_mask == clas
            true_label = mask == clas

            if true_label.long().sum().item() == 0:  # no exist label in this loop
                iou_per_class.append(np.nan)
            else:
                intersect = (
                    torch.logical_and(true_class, true_label).sum().float().item()
                )
                union = torch.logical_or(true_class, true_label).sum().float().item()

                iou = (intersect + smooth) / (union + smooth)
                dice = (2 * intersect + smooth) / (union + smooth)
                iou_per_class.append(iou)
                dice_per_class.append(dice)
        return np.nanmean(iou_per_class), np.nanmean(dice_per_class)


def pixel_accuracy(output, mask):
    with torch.no_grad():
        output = torch.argmax(F.softmax(output, dim=1), dim=1)
        correct = torch.eq(output, mask).int()
        accuracy = float(correct.sum()) / float(correct.numel())
    return accuracy


def predict_image_mask_miou(
    model,
    image,
    mask,
    mean=[0.60258, 0.44218, 0.57057],
    std=[0.30052, 0.27571, 0.27647],
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu"),
):
    model.eval()
    # t = T.Compose([T.ToTensor(), T.Normalize(mean, std)])
    # image = t(image)
    model.to(device)
    image = image.to(device)
    mask = mask.to(device)
    with torch.no_grad():

        # image = image.unsqueeze(0)
        # mask = mask.unsqueeze(0)

        output = model(image)
        score = mIoU(output, mask)
        masked = torch.argmax(output, dim=1)
        masked = masked.cpu().squeeze(0)
    return score # masked, score


def predict_image_mask_pixel(
    model,
    image,
    mask,
    mean=[0.60258, 0.44218, 0.57057],
    std=[0.30052, 0.27571, 0.27647],
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu"),
):
    model.eval()
    # t = T.Compose([T.ToTensor(), T.Normalize(mean, std)])
    # image = t(image)
    model.to(device)

    image = image.to(device)
    mask = mask.to(device)
    with torch.no_grad():

        # image = image.unsqueeze(0)
        # mask = mask.unsqueeze(0)

        output = model(image)
        acc = pixel_accuracy(output, mask)
        masked = torch.argmax(output, dim=1)
        masked = masked.cpu().squeeze(0)
    return acc # masked, acc

def compute_miou_acc(model, test_loader):
    model.eval()
    model.to('cuda')
    
    accuracy = []
    ious = []
    dices = []
    with torch.no_grad():
        for x, y in tqdm(test_loader):
            x = x.to('cuda')
            y = y.to('cuda')
            output = model(x)

            acc = pixel_accuracy(output, y)
            iou, dic =  mIoU(output, y)

            # print(iou)

            accuracy.append(acc)
            ious.append(iou)
            dices.append(dic)

    return sum(accuracy) / len(accuracy), sum(ious) / len(ious), sum(dices) / len(dices)
            

            



def miou_score(model, test_set):
    score_iou = []
    for img, mask in tqdm(test_set):
        # img, mask = test_set[i]
        _, score = predict_image_mask_miou(model, img, mask)
        score_iou.append(score)
    return score_iou / len(score_iou)


def pixel_acc(model, test_set):
    accuracy = []
    for img, mask in tqdm(test_set):
        # img, mask = test_set[i]
        _, acc = predict_image_mask_pixel(model, img, mask)
        accuracy.append(acc)
    return accuracy / len(accuracy)
