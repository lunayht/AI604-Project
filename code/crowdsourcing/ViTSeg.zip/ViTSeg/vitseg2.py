#!/usr/bin/env python
# coding: utf-8

# In[1]:




# In[2]:





# In[ ]:





# In[4]:



import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class PositionEmbs(nn.Module):
    def __init__(self, num_patches, emb_dim, dropout_rate=0.1):
        super(PositionEmbs, self).__init__()
        self.pos_embedding = nn.Parameter(torch.randn(1, num_patches+1, emb_dim))
        if dropout_rate > 0:
            self.dropout = nn.Dropout(dropout_rate)
        else:
            self.dropout = None

    def forward(self, x):
        out = x + self.pos_embedding

        if self.dropout:
            out = self.dropout(out)

        return out


class MlpBlock(nn.Module):
    """ Transformer Feed-Forward Block """
    def __init__(self, in_dim, mlp_dim, out_dim, dropout_rate=0.1):
        super(MlpBlock, self).__init__()

        # init layers
        self.fc1 = nn.Linear(in_dim, mlp_dim)
        self.fc2 = nn.Linear(mlp_dim, out_dim)
        self.act = nn.GELU()
        if dropout_rate > 0.0:
            self.dropout1 = nn.Dropout(dropout_rate)
            self.dropout2 = nn.Dropout(dropout_rate)
        else:
            self.dropout1 = None
            self.dropout2 = None

    def forward(self, x):

        out = self.fc1(x)
        out = self.act(out)
        if self.dropout1:
            out = self.dropout1(out)

        out = self.fc2(out)
        out = self.dropout2(out)
        return out


class LinearGeneral(nn.Module):
    def __init__(self, in_dim=(768,), feat_dim=(12, 64)):
        super(LinearGeneral, self).__init__()

        self.weight = nn.Parameter(torch.randn(*in_dim, *feat_dim))
        self.bias = nn.Parameter(torch.zeros(*feat_dim))

    def forward(self, x, dims):
        a = torch.tensordot(x, self.weight, dims=dims) + self.bias
        return a


class SelfAttention(nn.Module):
    def __init__(self, in_dim, heads=8, dropout_rate=0.1):
        super(SelfAttention, self).__init__()
        self.heads = heads
        self.head_dim = in_dim // heads
        self.scale = self.head_dim ** 0.5

        self.query = LinearGeneral((in_dim,), (self.heads, self.head_dim))
        self.key = LinearGeneral((in_dim,), (self.heads, self.head_dim))
        self.value = LinearGeneral((in_dim,), (self.heads, self.head_dim))
        self.out = LinearGeneral((self.heads, self.head_dim), (in_dim,))

        if dropout_rate > 0:
            self.dropout = nn.Dropout(dropout_rate)
        else:
            self.dropout = None

    def forward(self, x):
        b, n, _ = x.shape

        q = self.query(x, dims=([2], [0]))
        k = self.key(x, dims=([2], [0]))
        v = self.value(x, dims=([2], [0]))

        q = q.permute(0, 2, 1, 3)
        k = k.permute(0, 2, 1, 3)
        v = v.permute(0, 2, 1, 3)

        attn_weights = torch.matmul(q, k.transpose(-2, -1)) / self.scale
        attn_weights = F.softmax(attn_weights, dim=-1)
        out = torch.matmul(attn_weights, v)
        out = out.permute(0, 2, 1, 3)

        out = self.out(out, dims=([2, 3], [0, 1]))

        return out


class EncoderBlock(nn.Module):
    def __init__(self, in_dim, mlp_dim, num_heads, dropout_rate=0.1, attn_dropout_rate=0.1):
        super(EncoderBlock, self).__init__()

        self.norm1 = nn.LayerNorm(in_dim)
        self.attn = SelfAttention(in_dim, heads=num_heads, dropout_rate=attn_dropout_rate)
        if dropout_rate > 0:
            self.dropout = nn.Dropout(dropout_rate)
        else:
            self.dropout = None
        self.norm2 = nn.LayerNorm(in_dim)
        self.mlp = MlpBlock(in_dim, mlp_dim, in_dim, dropout_rate)

    def forward(self, x):
        residual = x
        out = self.norm1(x)
        out = self.attn(out)
        if self.dropout:
            out = self.dropout(out)
        out += residual
        residual = out

        out = self.norm2(out)
        out = self.mlp(out)
        out += residual
        return out


class Encoder(nn.Module):
    def __init__(self, num_patches, emb_dim, mlp_dim, num_layers=12, num_heads=12, dropout_rate=0.1, attn_dropout_rate=0.0):
        super(Encoder, self).__init__()

        # positional embedding
        self.pos_embedding = PositionEmbs(num_patches, emb_dim, dropout_rate)

        # encoder blocks
        in_dim = emb_dim
        self.encoder_layers = nn.ModuleList()
        for i in range(num_layers):
            layer = EncoderBlock(in_dim, mlp_dim, num_heads, dropout_rate, attn_dropout_rate)
            self.encoder_layers.append(layer)
        self.norm = nn.LayerNorm(in_dim)

    def forward(self, x):

        out = self.pos_embedding(x)

        for layer in self.encoder_layers:
            out = layer(out)

        out = self.norm(out)
        return out


class VisionTransformer(nn.Module):
    """ Vision Transformer """
    def __init__(self,
                 image_size=(1024, 1024),
                 patch_size=(256, 256),
                 emb_dim=4096,
                  mlp_dim=2048,
                 num_heads=12,
                 num_layers=12,
                 num_classes=22,
                 attn_dropout_rate=0.0,
                 dropout_rate=0.1,
                 feat_dim=None):
        super(VisionTransformer, self).__init__()
        h, w = image_size

        # embedding layer
        fh, fw = patch_size
        gh, gw = h // fh, w // fw
        num_patches = gh * gw
        self.embedding = nn.Conv2d(3, emb_dim, kernel_size=(fh, fw), stride=(fh, fw))
        # class token
        self.cls_token = nn.Parameter(torch.zeros(1, 1, emb_dim))

        # transformer
        self.transformer = Encoder(
            num_patches=num_patches,
            emb_dim=emb_dim,
            mlp_dim=mlp_dim,
            num_layers=num_layers,
            num_heads=num_heads,
            dropout_rate=dropout_rate,
            attn_dropout_rate=attn_dropout_rate)

        # classfier
        self.classifier = nn.Linear(emb_dim, num_classes)
        self.deconv1= nn.ConvTranspose2d(16, 32, 4, stride=4)
        self.deconv_head = nn.Sequential(nn.ConvTranspose2d(17, 32, 4, stride=4),
                                                   nn.BatchNorm2d(32),
                                                   nn.ReLU(),
                                         nn.ConvTranspose2d(32, 32, 4, stride=4),
                                         nn.BatchNorm2d(32),
                                         nn.ReLU(),
                                         nn.Conv2d(in_channels=32, out_channels=num_classes,
                                                   kernel_size=3, stride=1,padding=1)
                                         )

    def forward(self, x):
        emb = self.embedding(x)     # (n, c, gh, gw)
        emb = emb.permute(0, 2, 3, 1)  # (n, gh, hw, c)
        b, h, w, c = emb.shape
        emb = emb.reshape(b, h * w, c)
        print(emb.shape)

        # prepend class token
        cls_token = self.cls_token.repeat(b, 1, 1)
        emb = torch.cat([cls_token, emb], dim=1)

        # transformer
        feat = self.transformer(emb)
        x = feat.reshape((-1, feat.shape[1], 64,64))
#         x=self.deconv1(x)
#         print(feat.shape)
#         print(feat[:, 0].shape)

        # classifier
        # logits = self.classifier(feat[:, 0])
        logits=self.deconv_head (x)
        return logits




# In[5]:



if __name__=='__main__':
    # batch_size = 64
    epochs = 200
    lr = 3e-5
    gamma = 0.7
    seed = 42
    device = 'cuda'

    model = VisionTransformer(
        image_size=(1024, 1024),
        patch_size=(256, 256),
        num_classes=22,
        emb_dim =2048,
        num_layers=6,
        num_heads=16,
        mlp_dim=2048,
        attn_dropout_rate = 0.0,
        dropout_rate = 0.1,
    ).cuda()


    batch_size = 2

    data_dir = './Patches'
    train_img_dir = os.path.join(data_dir, "Largetrain/images")
    train_msk_dir = os.path.join(data_dir, "Largetrain/masks")

    # test_img_dir = os.path.join(data_dir, "test/images")
    # test_msk_dir = os.path.join(data_dir, "test/masks")

    train_img_files = os.listdir(train_img_dir)
    train_msk_files = os.listdir(train_msk_dir)

    # test_img_files = os.listdir(test_img_dir)
    # test_msk_files = os.listdir(test_msk_dir)

    # print(len(train_img_files), len(test_img_files))

    train_dataset = CancerDataset(train_img_dir, train_msk_dir, transform=transforms.Compose([
        transforms.ToTensor()]))
    print(len(train_dataset))

    # test_dataset = CancerDataset(test_img_dir, test_msk_dir, transform=transforms.Compose([
    #     transforms.ToTensor()]))
    # print(len(test_dataset))

    train_loader = DataLoader(train_dataset, batch_size=batch_size)

    # test_loader = DataLoader(test_dataset, batch_size=batch_size)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    step_losses = []
    epoch_losses = []

    # epochs = 5
    for epoch in tqdm(range(epochs)):
        epoch_loss = 0
        for X, Y in tqdm(train_loader, total=len(train_loader), leave=False):
            X, Y = X.cuda(), Y.cuda()
            optimizer.zero_grad()
            Y_pred = model(X)
            loss = criterion(Y_pred, Y)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()
            step_losses.append(loss.item())
        epoch_losses.append(epoch_loss / len(train_loader))
    torch.save(model.state_dict(), 'pytorchunet.pth')

    # X, Y = next(iter(test_loader))
    # X, Y = X.to(device), Y.to(device)
    # Y_pred = model(X)
    # print(Y_pred.shape)
    # Y_pred = torch.argmax(Y_pred, dim=1)
    # print(Y_pred.shape)

    # fig, axes = plt.subplots(16, 3, figsize=(3 * 5, 16 * 5))
    #
    # for i in range(16):
    #     landscape = X[i].permute(1, 2, 0).cpu().detach().numpy()
    #     label_class = Y[i].cpu().detach().numpy()
    #     label_class_predicted = Y_pred[i].cpu().detach().numpy()
    #
    #     axes[i, 0].imshow(landscape)
    #     axes[i, 0].set_title("Landscape")
    #     axes[i, 1].imshow(label_class)
    #     axes[i, 1].set_title("Label Class")
    #     axes[i, 2].imshow(label_class_predicted)
    #     axes[i, 2].set_title("Label Class - Predicted")






