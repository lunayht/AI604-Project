import os
import numpy as np
import pandas as pd
from glob import glob
# import cv2
from PIL import Image
# import matplotlib.pyplot as plt
from tqdm import tqdm


import torch
import torchvision
import torchvision.transforms as transforms
import torch.nn.functional as F

from torch import nn, einsum
from einops import rearrange, repeat
from einops.layers.torch import Rearrange

from sklearn.model_selection import train_test_split
from torch.optim.lr_scheduler import StepLR
from torch.utils.data import DataLoader, Dataset
from torchvision import datasets
import torch.optim as optim
from SETR import *
from PositionalEncoding import *
from ResNet import *
from IntmdSequential import *
from Transformer import *
from HybridSETR import *
os.environ["CUDA_VISIBLE_DEVICES"] = '3'

class CancerDataset(Dataset):

    def __init__(self, image_dir, mask_dir, transform=None):
        super(CancerDataset, self).__init__()
        self.image_dir = image_dir
        self.image_files = os.listdir(image_dir)
        self.mask_dir = mask_dir
        self.transform = transform

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, index):
        image_file = self.image_files[index]
        mask_file = self.image_files[index]
        image_path = os.path.join(self.image_dir, image_file)
        mask_path = os.path.join(self.mask_dir, mask_file)
        image = Image.open(image_path).convert('RGB')
        #         image = np.array(image)
        mask = Image.open(mask_path)
        mask = np.array(mask)
        if self.transform:
            image = self.transform(image)

        label = torch.Tensor(mask).long()
        return image, label




if __name__=='__main__':
    # batch_size = 64
    epochs = 50
    lr = 3e-5
    gamma = 0.7
    seed = 42
    device = 'cuda'
    _, model =SETR_PUP_S().cuda

    # model = ViT(
    #     image_size=(512,512),
    #     patch_size=(128,128),
    #     num_classes=22,
    #     dim=4096,
    #     depth=6,
    #     heads=6,
    #     mlp_dim=2048,
    #     dropout=0.1,
    #     emb_dropout=0.1
    # ).cuda()
    model = nn.DataParallel(model)
    model = model.cuda()
    batch_size = 16
    print('--------------loading data-------------')
    data_dir = '../Crowd/Patches'
    train_img_dir = os.path.join(data_dir, "train/images")
    train_msk_dir = os.path.join(data_dir, "train/masks")

    # test_img_dir = os.path.join(data_dir, "test/images")
    # test_msk_dir = os.path.join(data_dir, "test/masks")

    train_img_files = os.listdir(train_img_dir)
    train_msk_files = os.listdir(train_msk_dir)

    # test_img_files = os.listdir(test_img_dir)
    # test_msk_files = os.listdir(test_msk_dir)

    # print(len(train_img_files), len(test_img_files))

    train_dataset = CancerDataset(train_img_dir, train_msk_dir, transform=transforms.Compose([
        transforms.ToTensor()]))
    print(len(train_dataset))

    # test_dataset = CancerDataset(test_img_dir, test_msk_dir, transform=transforms.Compose([
    #     transforms.ToTensor()]))
    # print(len(test_dataset))

    train_loader = DataLoader(train_dataset, batch_size=batch_size, num_workers=16, shuffle=True)

    # test_loader = DataLoader(test_dataset, batch_size=batch_size)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    step_losses = []
    epoch_losses = []

    # epochs = 5
    for epoch in range(epochs):
        epoch_loss = 0
        total=0
        for X, Y in tqdm(train_loader):
            X, Y = X.cuda(), Y.cuda()
            optimizer.zero_grad()
            Y_pred = model(X)
            loss = criterion(Y_pred, Y)
            loss.backward()
            optimizer.step()
            total += Y.shape[0]
            epoch_loss += loss.item()
        epoch_loss= epoch_loss/total
        print(f" epoch: {epoch} train_loss : {epoch_loss:.4f} \n" )
        # epoch_losses.append(epoch_loss / len(train_loader))

    torch.save(model.module.state_dict(), 'pytorchvitunet2.pth')

    # X, Y = next(iter(test_loader))
    # X, Y = X.to(device), Y.to(device)
    # Y_pred = model(X)
    # print(Y_pred.shape)
    # Y_pred = torch.argmax(Y_pred, dim=1)
    # print(Y_pred.shape)

    # fig, axes = plt.subplots(16, 3, figsize=(3 * 5, 16 * 5))
    #
    # for i in range(16):
    #     landscape = X[i].permute(1, 2, 0).cpu().detach().numpy()
    #     label_class = Y[i].cpu().detach().numpy()
    #     label_class_predicted = Y_pred[i].cpu().detach().numpy()
    #
    #     axes[i, 0].imshow(landscape)
    #     axes[i, 0].set_title("Landscape")
    #     axes[i, 1].imshow(label_class)
    #     axes[i, 1].set_title("Label Class")
    #     axes[i, 2].imshow(label_class_predicted)
    #     axes[i, 2].set_title("Label Class - Predicted")

# def conv_block(self, in_channels, out_channels):
#     block = nn.Sequential(
#         nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=3, stride=1, padding=1),
#         nn.ReLU(),
#         nn.BatchNorm2d(num_features=out_channels),
#         nn.Conv2d(in_channels=out_channels, out_channels=out_channels, kernel_size=3, stride=1, padding=1),
#         nn.ReLU(),
#         nn.BatchNorm2d(num_features=out_channels))
#     return block


